# shellcheck shell=sh disable=SC2034
KEYBOX_URL="https://rawbin.netlify.app/key"
ATTESTATION_URL="https://rawbin.netlify.app/clips/attestation"
HMA_CONFIG_URL="https://rawbin.netlify.app/clips/hma"
CATALOG_URL="https://rawbin.netlify.app/key/catalog"
GOOGLE_REVOCATION_URL="https://android.googleapis.com/attestation/status?encrypted=0"
RKA_HOST="rp.mhmrdd.me"
RKA_TCP=59416
RKA_TOKEN="${RKA_TOKEN:-yurikey-5b70e270d6d69cd399c59ca3d62ccf6e}"
FALLBACK_KEYBOXES="Yuri/8 OGCOMPLEX/1 Trigon/1 Evokerr/1 Fateh/1"
TEE_CHECK_URL="https://rawbin.netlify.app/file/1c78f95e-990d-4975-a2c7-eaa249c89feb"
